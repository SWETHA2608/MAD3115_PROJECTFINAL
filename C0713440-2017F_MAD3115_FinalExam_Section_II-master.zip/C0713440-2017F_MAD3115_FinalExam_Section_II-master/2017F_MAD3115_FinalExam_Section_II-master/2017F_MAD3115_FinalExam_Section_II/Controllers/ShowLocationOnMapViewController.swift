//
//  ShowLocationOnMapViewController.swift
//  2017F_MAD3115_FinalExam_Section_II
//
//  Created by moxDroid on 2017-11-02.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Roll No.    :
//  Name        :

import UIKit
import MapKit

class ShowLocationOnMapViewController: UIViewController {

    @IBOutlet weak var Map: MKMapView!
    
    let initialLocation = CLLocation(latitude: 64.6532, longitude: -10.3832)
    
    let sahara = CLLocation(latitude:20.5937,longitude:78.9629)
   
    let ripleyaquarium = CLLocation(latitude: 43.6425,longitude:79.3871)
    let CNTowerLocation = CLLocation(latitude:79.3871, longitude:43.6426)
    
 
    let regionRadius: CLLocationDistance = 1000
    
    var locationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Map.mapType = MKMapType.hybrid
        Map.isPitchEnabled = true
        Map.isZoomEnabled = true
        Map.isScrollEnabled = true
        Map.showsUserLocation = true
   
        
        
        centerMapOnLocation(location: sahara)
        setPoinAnotation(location: sahara, title: "Sahara Desert", subTitle: "India")
        
        centerMapOnLocation(location: ripleyaquarium);         setPoinAnotation(location: ripleyaquarium, title: "TORONTO", subTitle: "toronto")
        
        
        centerMapOnLocation(location: CNTowerLocation);
         setPoinAnotation(location: CNTowerLocation, title: "CNTOWER", subTitle: "toronto")
       
        
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestWhenInUseAuthorization()
         locationManager.delegate = self
       
        DispatchQueue.main.async {
            
       
        
        
    }

    }
    
    func setAllLocation (){
        
    }
    
    
    
    func centerMapOnLocation(location: CLLocation) {
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate,
                                                                  regionRadius, regionRadius)
        Map.setRegion(coordinateRegion, animated: true)
    }
    
    func setPoinAnotation(location: CLLocation,title: String, subTitle: String){
        
       
        
        if self.Map.annotations.count != 0{
            let annotation = self.Map.annotations[0]
            self.Map.removeAnnotation(annotation)
        }
        
        let myAnnotation: MKPointAnnotation = MKPointAnnotation()
        myAnnotation.coordinate = CLLocationCoordinate2DMake(location.coordinate.latitude, location.coordinate.longitude);
        myAnnotation.title = title
        myAnnotation.subtitle = subTitle
        Map.addAnnotation(myAnnotation)
    }
    
    @IBAction func chengeMapType(_ sender: UISegmentedControl) {
        
        if sender.selectedSegmentIndex == 0{
            Map.mapType = MKMapType.standard
        }else{
            Map.mapType = MKMapType.satellite
        }
    }
    
}

extension ShowLocationOnMapViewController: CLLocationManagerDelegate{
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        let currentLocation = locations[0]
        
        self.setPoinAnotation(location: currentLocation, title: "Current Location", subTitle: "Sub title")
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Error : No location found")
    }
}

    
    
    

