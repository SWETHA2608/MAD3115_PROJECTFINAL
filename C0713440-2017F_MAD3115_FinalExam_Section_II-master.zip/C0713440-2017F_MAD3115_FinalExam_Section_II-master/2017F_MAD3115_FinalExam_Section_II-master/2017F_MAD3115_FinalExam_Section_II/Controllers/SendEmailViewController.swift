//
//  SendEmailViewController.swift
//  2017F_MAD3115_FinalExam_Section_II
//
//  Created by moxDroid on 2017-11-02.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Roll No.    : C0713440
//  Name        : S.Swetha

import UIKit
import MessageUI

class SendEmailViewController: UIViewController,MFMailComposeViewControllerDelegate {

   
    @IBOutlet weak var Content: UITextField!
    @IBOutlet weak var EmailBody: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    
    
    @IBAction func send(_ sender: UIButton) {
        
        if MFMailComposeViewController.canSendMail() {
            print("Send Mail Sucessfully");
            let picker = MFMailComposeViewController()
            picker.mailComposeDelegate = self
            picker.setSubject(Content.text!)
            picker.setMessageBody(EmailBody.text!, isHTML: true)
            present(picker, animated: true, completion: nil)
        }else{
            print("Didnt send Mail");
        }
    }
    
    // MFMailComposeViewControllerDelegate
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        dismiss(animated: true, completion: nil)
    }
    
}

        
        
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */


